import org.junit.Test;
import java.util.Date;
import static org.junit.Assert.*;

public class AppointmentTest {
	@Test
	public void testCreateAppointment() {
		Appointment appointment = new Appointment("00001", new Date(), "Appointment Description");
		assertNotNull(appointment);
	}
	
	@Test
	public void testAppointmentID() {
		Appointment appointment = new Appointment("00001", new Date(), "Appointment Description");
		assertEquals("00001", appointment.getAppointmentID());
	}
	
	@Test
	public void testAppointmentDate() {
		Appointment appointment = new Appointment ("00001", appointmentDate, "Appointment Description");
		assertEquals(appointmentDate, appointment.getAppointmentDate());
	}
	
	@Test (expected = IllegalArgumentException.class)
	public void testAppointmentDateInThePast() {
		Date appointmentDate = new Date(System.currentTimeMillis() - 1000 * 60 * 60 * 24);
		Appointment appointment = new Appointment("00001", appointmentDate, "Appointment Description");
	}
	
	@Test
	public void testAppointmentDescription() {
		Appointment appointment = new Appointment("00001", new Date(), "Appointment Description");
		assertEquals("Appointment Description", appointment.getDescription());
	}
	
	@Test (expected = IllegalArgumentExcetion.class)
	public void testAppointmentIDTooLong() {
		Appointment appointment = new Appointment("00000000001", new Date(), "Appointment Description");
	}
	
	@Test(expected = NullPointerException)
	public void testAppointmentIDNull() {
		Appointment appointment = new Appointment(null, new Date(), "Appointment Description");
	}
	
	@Test(expected = NullPointerException.class)
	public void testAppointmentDateNull() {
		Appointment appointment = new Appointment("00001", null, "Appointment Description");
	}
	
	@Test(expected NullPointerException.class)
	public void testAppointmentDescriptionNull() {
		Appointment appointment = new Appointment("00001", new Date(), null);
	}
	
	@Test(expected IllegalArgumentException.class)
	public void testAppointmentDescriptionTooLong() {
		String description = "Appointment Description that is too long should throw an IllegalArgumentException";
		Appointment appointment = new Appointment("00001", new Date(), description);
	}
}

