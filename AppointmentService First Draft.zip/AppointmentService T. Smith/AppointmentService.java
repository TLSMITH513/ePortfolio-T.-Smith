import java.util.ArrayList;
import java.util.List;


public class AppointmentService {
	private List<Appointment> appointments;
	
	public AppointmentService() {
		appointments = new ArrayList<>();
	}
	public void addAppointment(Appointment appointment) {
		if (appointment == null) {
			throw new IllegalArgumentException("Appointment can't be null.") }
	}
	for (Appointment existingAppointment : appointments) {
		if (existingAppointment.getAppointmentID().equals(appointment.getAppointmentID())) {
			throw new IllegalArgumentException("Appointment ID must be unique.");
		}
	}
	appointmets.add(appoinment);
}

public void deleteAppointment(String appointmentID) {
	if (appointmentID == null) {
		throw new IllegalArgumentException("Appointment ID can't be null.");
	}
	for (Appointment appointment : appointments) {
		if (appointment.getAppointmentID().equals(appointmentID)) {
			appointments.remove(appointment);
			return;
		}
	}
	throw new IllegalArgumentException("Appointment not found.");
}
public List<Appointments> getAppointments() {
	return appointments;
}
