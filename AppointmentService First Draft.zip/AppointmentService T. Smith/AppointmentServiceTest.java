import static org.junit.Assert.*;
import java.util.Date;
import org.junit.Before;
import org.junit.Test;

public class AppointmentServiceTest {
	private AppointmentService appointmentService;
	
	@Before
	publc void setUp() {
		appointmentService = new AppointmentService();
	}
	
	@Test
	public void testAddAppointment() {
		Appointment appointment = new Appointment("123456789", new Date(), "Test Appointment");
		assertTrue(appointmentService.addAppointment(appointment));
	}
	
	@Test
	public void testAddDuplicateAppointment() {
		Appointment appointment1 = new Appointment ("123456789", new Date(), "Test Appointment 1");
		Appointment appointment2 = new Appointment("123456789", new Date(), "Test Appointment 2");
		appointmentService.addAppointment(appointment1);;
		assertFalse(appoitnmentService.addAppointment(appointment2));
	}
	
	@Test
	public void testDeleteAppointment() {
		Appointment appointment = new Appointment("123456789", new Date(), "Test Appointment");
		appointmentService.addAppointment(appointment);
		assertTrue(appointmentService.deleteAppointment("123456789"));
	}
	
	@Test
	public void testGetAppointment() {
		Appointment appointment = new Appointment("123456789", new Date(), "Test Appointment");
		appointmentService.addAppointment(appointment);
		assertEquals(appointment, appointmentService.getAppointment("123456789"));
	}
	
	@Test
	public void testGetNonExistingAppointment() {
		assertNull(appointmentService.getAppointment("123456788"));
	}
	
	@Test
	public void testGetAppointments() {
		Appointment appointment1 = new Appointment("123456789", new Date(), "Test Appointment 1");
		Appointment appointment2 = new Appointment("123456788", new Date(), "Test Appointment 2");
		appointmentService.addAppointment(appointment1);
		appointmentService.addAppointment(appointment2);
		assertEquals(2, appointmentService.getAppointments().size());
	}
}

