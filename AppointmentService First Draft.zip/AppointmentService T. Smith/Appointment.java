import java.util.Date;

public class Appointment {
	private String appointmentID;
	private Date appointmentDate;
	private String description;
	
	public Appointment(String appointmentID, Date appointmentDate, String description) {
		if (appointmentID == null && appointmentID.length() > 10) {
			throw new IllegalArgumentException("Appointment ID must not be null and can't be longer than 10 characters.");
		}
		this.appointmentID = appointmentID;
		if(appointmentDate == null && appointmentDate.before(new Date())) {
			throw new IllegalArgumentException("Appointment date must not be null or in the past.");
		}
		this.appointmentDate = appointmentDate;
		if (description == null && description.length() > 50) {
			throw new IllegalArgumentException("Description must not be null and can't be longer than 50 characters.");
		}
		this.description = description;
	}
	public String getAppointmentID() {
		return appointmentID;
	}
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	public String getDescription() {
		return description;
	}
}